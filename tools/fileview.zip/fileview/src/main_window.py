import os
from datetime import datetime
from PyQt6.QtWidgets import (
    QMainWindow, QSplitter, QTableView, QTreeView, QLabel, QVBoxLayout, QWidget,
    QHBoxLayout, QPushButton, QFileDialog, QMessageBox, QProgressBar,
    QHeaderView, QLineEdit
)
from PyQt6.QtCore import Qt, QDir, QSortFilterProxyModel
from PyQt6.QtGui import QFont, QFileSystemModel

from file_model import FileTableModel
from scan_thread import ScanThread
from hex_viewer import HexViewer
from hex_editor import HexEditor


class FileFilterProxyModel(QSortFilterProxyModel):
    """
    Filters rows by matching the search text against name, type, OR full
    path (case-insensitive substring), rather than QSortFilterProxyModel's
    default of matching only one fixed column. Sorting is left to the base
    class, which delegates to FileTableModel.sort().
    """

    def filterAcceptsRow(self, source_row, source_parent):
        text = self.filterRegularExpression().pattern().lower()
        if not text:
            return True

        model = self.sourceModel()
        info = model.get_file_info(source_row)
        if info is None:
            return False

        return (
            text in info['name'].lower()
            or text in info['type'].lower()
            or text in info['path'].lower()
        )


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("File Scanner & Hex Viewer")
        self.resize(1600, 900)

        self.current_root = None
        self.files_data = []
        self.current_model = None
        self.proxy_model = None
        self.scan_thread = None
        self.hex_editor = None  # reused across calls instead of piling up windows

        self._setup_ui()
        self._load_styles()

    def _setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)

        # Toolbar
        toolbar = QHBoxLayout()
        self.btn_select_root = QPushButton("📁 Select Root Folder")
        self.btn_select_root.clicked.connect(self.select_root_folder)
        self.btn_full_scan = QPushButton("🔍 Full Recursive Scan")
        self.btn_full_scan.clicked.connect(self.start_full_scan)
        self.btn_cancel_scan = QPushButton("✖ Cancel Scan")
        self.btn_cancel_scan.clicked.connect(self.cancel_full_scan)
        self.btn_cancel_scan.setVisible(False)

        toolbar.addWidget(self.btn_select_root)
        toolbar.addWidget(self.btn_full_scan)
        toolbar.addWidget(self.btn_cancel_scan)
        toolbar.addStretch()

        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("Filter by name, extension, or path...")
        self.filter_edit.setClearButtonEnabled(True)
        self.filter_edit.setMaximumWidth(320)
        self.filter_edit.textChanged.connect(self.on_filter_changed)
        toolbar.addWidget(self.filter_edit)

        main_layout.addLayout(toolbar)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        main_layout.addWidget(self.progress)

        # Main Splitter
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left: Tree
        self.tree_model = QFileSystemModel()
        self.tree_view = QTreeView()
        self.tree_view.setModel(self.tree_model)
        self.tree_view.clicked.connect(self.on_tree_clicked)
        splitter.addWidget(self.tree_view)

        # Center: Table
        self.table = QTableView()
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSortingEnabled(True)
        self.table.clicked.connect(self.on_file_selected)
        splitter.addWidget(self.table)

        # Right: Info + Hex + Editor
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)

        self.info_label = QLabel("Select a root folder to begin")
        self.info_label.setWordWrap(True)
        self.info_label.setMinimumHeight(140)
        right_layout.addWidget(self.info_label)

        hex_title = QLabel("Hex Preview")
        hex_title.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        right_layout.addWidget(hex_title)

        self.hex_viewer = HexViewer()
        right_layout.addWidget(self.hex_viewer)

        # Hex Editor Button
        editor_btn = QPushButton("✏️ Open in Hex Editor")
        editor_btn.clicked.connect(self.open_in_hex_editor)
        right_layout.addWidget(editor_btn)

        splitter.addWidget(right_panel)
        splitter.setSizes([380, 650, 570])
        main_layout.addWidget(splitter)

    def _load_styles(self):
        try:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            qss_path = os.path.join(base_dir, "style.qss")
            if os.path.exists(qss_path):
                with open(qss_path, "r", encoding="utf-8") as f:
                    self.setStyleSheet(f.read())
        except Exception as e:
            print(f"Stylesheet error: {e}")

    def _set_table_data(self, results: list):
        """Wrap results in the table model + filter/sort proxy and attach to the view."""
        self.files_data = results
        self.current_model = FileTableModel(results)

        self.proxy_model = FileFilterProxyModel()
        self.proxy_model.setSourceModel(self.current_model)
        self.proxy_model.setFilterRegularExpression(self.filter_edit.text())

        self.table.setModel(self.proxy_model)

    def on_filter_changed(self, text: str):
        if self.proxy_model is not None:
            self.proxy_model.setFilterRegularExpression(text)

    def select_root_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Root Folder")
        if folder:
            self.current_root = folder
            self.tree_model.setRootPath(folder)
            root_index = self.tree_model.index(folder)
            self.tree_view.setRootIndex(root_index)
            self.tree_view.expand(root_index)
            self.show_files_in_folder(folder)

    def on_tree_clicked(self, index):
        path = self.tree_model.filePath(index)
        self.show_files_in_folder(path)

    def show_files_in_folder(self, folder_path: str):
        if not os.path.isdir(folder_path):
            return
        results = []
        try:
            for item in os.listdir(folder_path):
                full_path = os.path.join(folder_path, item)
                if os.path.isfile(full_path):
                    try:
                        stat = os.stat(full_path)
                        ext = os.path.splitext(item)[1].lower() or "(none)"
                        results.append({
                            'name': item,
                            'path': full_path,
                            'size': stat.st_size,
                            'size_str': ScanThread._format_size(stat.st_size),
                            'type': ext,
                            'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M'),
                            'modified_ts': stat.st_mtime
                        })
                    except Exception:
                        continue
            results.sort(key=lambda x: x['modified_ts'], reverse=True)
        except Exception as e:
            print(f"Error reading folder: {e}")

        self._set_table_data(results)

    def on_file_selected(self, proxy_index):
        if self.proxy_model is None:
            return
        source_index = self.proxy_model.mapToSource(proxy_index)
        row = source_index.row()
        if row < 0 or row >= len(self.files_data):
            return
        file_info = self.files_data[row]

        info = f"""
        <b>Name:</b> {file_info['name']}<br>
        <b>Type:</b> {file_info['type']}<br>
        <b>Size:</b> {file_info['size_str']}<br>
        <b>Modified:</b> {file_info['modified']}<br>
        <b>Path:</b> {file_info['path']}
        """
        self.info_label.setText(info)
        self.hex_viewer.show_hex(file_info['path'])

    def _current_selected_file_info(self):
        """Resolve the selected table row (through the proxy model) to a file_info dict, or None."""
        if self.current_model is None or self.proxy_model is None or len(self.files_data) == 0:
            return None

        selection_model = self.table.selectionModel()
        if not selection_model:
            return None

        selected = selection_model.selectedRows()
        if selected:
            proxy_index = selected[0]
        else:
            proxy_index = self.table.currentIndex()
            if not proxy_index.isValid():
                return None

        source_index = self.proxy_model.mapToSource(proxy_index)
        row = source_index.row()
        if row < 0 or row >= len(self.files_data):
            return None

        return self.files_data[row]

    def open_in_hex_editor(self):
        """Open currently selected file in the Hex Editor, reusing one window instead of stacking new ones."""
        file_info = self._current_selected_file_info()
        if file_info is None:
            QMessageBox.warning(self, "No Selection", "Please select a file in the table first.")
            return

        if self.hex_editor is None:
            self.hex_editor = HexEditor()

        self.hex_editor.load_file(file_info['path'])

    def start_full_scan(self):
        if not self.current_root:
            QMessageBox.warning(self, "No Root", "Please select a root folder first.")
            return
        self.btn_full_scan.setEnabled(False)
        self.btn_cancel_scan.setVisible(True)
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)

        self.scan_thread = ScanThread(self.current_root)
        self.scan_thread.progress.connect(self.update_progress)
        self.scan_thread.finished.connect(self.full_scan_finished)
        self.scan_thread.cancelled.connect(self.full_scan_cancelled)
        self.scan_thread.start()

    def cancel_full_scan(self):
        if self.scan_thread is not None and self.scan_thread.isRunning():
            self.scan_thread.requestInterruption()
            self.btn_cancel_scan.setEnabled(False)
            self.progress.setFormat("Cancelling...")

    def update_progress(self, count: int, message: str):
        self.progress.setFormat(f"{message} ({count:,})")

    def _reset_scan_ui(self):
        self.progress.setVisible(False)
        self.btn_full_scan.setEnabled(True)
        self.btn_cancel_scan.setVisible(False)
        self.btn_cancel_scan.setEnabled(True)

    def full_scan_finished(self, results: list):
        self._set_table_data(results)
        self._reset_scan_ui()
        QMessageBox.information(self, "Full Scan Complete",
                              f"Found {len(results):,} files recursively in:\n{self.current_root}")

    def full_scan_cancelled(self, results: list):
        self._set_table_data(results)
        self._reset_scan_ui()
        QMessageBox.information(self, "Scan Cancelled",
                              f"Scan stopped early. {len(results):,} files found before cancelling.")
